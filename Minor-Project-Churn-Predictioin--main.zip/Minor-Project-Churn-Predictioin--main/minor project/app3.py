import gc

import streamlit as st
import pandas as pd
import numpy as np
import base64
import matplotlib.pyplot as plt


from sklearn.model_selection import train_test_split
from sklearn.preprocessing import RobustScaler, OrdinalEncoder
from sklearn.metrics import roc_auc_score, auc, roc_curve, precision_recall_curve, f1_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier

# from catboost import CatBoostClassifier
import xgboost as xgb
# import lightgbm as lgbm

st.title('E-Commerce Customer Churn Prediction')

df_churn = pd.read_csv('Ecomm.csv')
df_churn = df_churn.drop(
    ['CustomerID', 'PreferredLoginDevice', 'CouponUsed'], axis=1)
df1 = df_churn.drop('Churn', axis=1)
df_train = df_churn.sample(frac=0.7, random_state=200)
df_test = df_churn.drop(df_train.index)
st.header('Churn Data Overview')
st.write('Data Dimension: ' +
         str(df_churn.shape[0]) + ' rows and ' + str(df_churn.shape[1]) + ' columns.')
st.dataframe(df_churn)

X = df_churn.drop("Churn", axis=1)
y = df_churn['Churn']


num_cols = X.select_dtypes(include=['int64', 'float64']).columns
cat_cols = X.select_dtypes(include=['object']).columns

ordinal_encoder = OrdinalEncoder()
X[cat_cols] = ordinal_encoder.fit_transform(X[cat_cols])

transformer = RobustScaler()
X[num_cols] = transformer.fit_transform(X[num_cols])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42)


@st.cache_data
def download_dataset(df):
    csv = df.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    href = f'<a href="data:file/csv;base64,{b64}" download="churn_data.csv">Download CSV File</a>'
    return href


st.set_option('deprecation.showPyplotGlobalUse', False)
st.markdown(download_dataset(df_churn), unsafe_allow_html=True)

st.markdown("## Prediction Result")


st.sidebar.markdown("## Predict Customer Churn Rate")
classifier_name = st.sidebar.selectbox(
    'Select a Classifier',
    ('Random Forest', 'Decision Tree', 'XGBoost')
)


def get_classifier(clf_name):
    if clf_name == 'Random Forest':
        clf = RandomForestClassifier()
    elif clf_name == 'Decision Tree':
        clf = DecisionTreeClassifier()
    else:
        clf = xgb.XGBClassifier()
    return clf


clf = get_classifier(classifier_name)


def get_transformed_data(test_data=None):
    X = df_train.drop("Churn", axis=1)

    if test_data is None:
        test_data = df_test.copy()

    y_test = test_data['Churn'].values
    X_test = test_data.drop("Churn", axis=1)

    num_cols = X.select_dtypes(include=['int64', 'float64']).columns
    cat_cols = X.select_dtypes(include=['object']).columns

    ordinal_encoder = OrdinalEncoder()
    X[cat_cols] = ordinal_encoder.fit_transform(X[cat_cols])
    X_test[cat_cols] = ordinal_encoder.transform(X_test[cat_cols])

    transformer = RobustScaler()
    X[num_cols] = transformer.fit_transform(X[num_cols])
    X_test[num_cols] = transformer.transform(X_test[num_cols])

    del X
    gc.collect()
    return X_test, y_test


def fit_model(clf):
    if clf == RandomForestClassifier():
        fitted_model = clf.fit(X_train, y_train)
    if clf == DecisionTreeClassifier():
        fitted_model = clf.fit(X_train, y_train)
    else:
        fitted_model = clf.fit(X_train, y_train)
    return fitted_model


def make_prediction(X_test):
    test_pred = fit_model(clf).predict(X_test)
    # st.write(X_test)
    try:
        test_pred = clf.predict_proba(X_test)[:, 1]  # probability of getting 1
    except AttributeError as ae:

        test_pred = clf.predict(X_test)

    return test_pred


st.sidebar.markdown('## User Input')


def user_input_features():
    selected_values = {}
    for column in df1.columns:
        if df1[column].dtype == 'object':
            # Categorical columns
            selected_values[column] = st.sidebar.selectbox(
                f'Select {column}', df1[column].unique())
        else:
            # Numerical columns
            min_val = df1[column].min()
            max_val = df1[column].max()
            selected_values[column] = st.sidebar.slider(
                f'Select {column}', min_val, max_val)

    features = pd.DataFrame(selected_values, index=[0])

    return features


input_df = user_input_features()

num_cols = input_df.select_dtypes(include=['int64', 'float64']).columns
cat_cols = input_df.select_dtypes(include=['object']).columns

X = df_train.drop("Churn", axis=1)
user_df = input_df.copy()
ordinal_encoder = OrdinalEncoder()
X[cat_cols] = ordinal_encoder.fit_transform(X[cat_cols])
user_df[cat_cols] = ordinal_encoder.transform(user_df[cat_cols])

transformer = RobustScaler()
X[num_cols] = transformer.fit_transform(X[num_cols])
user_df[num_cols] = transformer.transform(user_df[num_cols])


if st.sidebar.button('Predict'):
    test_pred = make_prediction(user_df)
    st.markdown(
        f"Prediction result : {'**Churned**' if test_pred[0]>0.5 else '**Not Churned**'} (Probability: {test_pred[0] : 0.2f}) ")
    st.write("User Input Features")
    st.dataframe(input_df)
